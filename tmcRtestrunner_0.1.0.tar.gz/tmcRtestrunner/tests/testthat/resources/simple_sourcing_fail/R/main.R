ret_true <- function() {
  return(TRUE)
}

#This function produces an error
ret_one <- function() {
  error in source code
}

add <- function(a, b) {
  return(a + b)
}
